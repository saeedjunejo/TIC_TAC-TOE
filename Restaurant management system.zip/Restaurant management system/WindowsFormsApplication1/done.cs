﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class done : Form
    {
        //itemsClass ic = new itemsClass();
        //double no = ic.randomNo();
        
        
        public done()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            itemsClass ice = new itemsClass();
            ice.finalize();
            this.Hide();
            
            //database2 d2 = new database2();
            //d2.add("insert into items(name,password)values('" + textBox1.Text + "'," + textBox2.Text + ")");
            
        }

        private void done_Load(object sender, EventArgs e)
        {
           
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            itemsClass ic = new itemsClass();
            double no = ic.randomNo();
            label6.Text = no.ToString();
            if (radioButton1.Checked)
            {
                database2 d2 = new database2();
                DateTime now1 = DateTime.Now;

                d2.add("insert into finalize(name,dateTime,status,recieptID)values('" + textBox1.Text + "','" + now1 + "','Dine in'," + no + ")");
               
            }
            else if (radioButton2.Checked)
            {
                database2 d2 = new database2();
                DateTime now1 = DateTime.Now;
                d2.add("insert into finalize(name,dateTime,status,recieptID)values('" + textBox1.Text + "','" + now1 + "','Take Away'," + no+ ")");
                
            }
            else
            {
                MessageBox.Show("Please complete the entry properly...");
            }
        }
    }
}
