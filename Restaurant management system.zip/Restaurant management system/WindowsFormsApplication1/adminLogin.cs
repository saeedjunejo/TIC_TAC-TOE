﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    class adminLogin
    {
        string userName;
        string password;
        //public string confirm;

       public string UserName
        {
            get
            { 
                return userName;
            }
            set
            {
                    userName = value;
            }
        }
       public string Password
       {
           get
           {
               return password;
           }
           set
           {
                   password = value;
           }
       }
        public void login()
        {
            if (userName=="jamil"&&password=="123")
            {
                admin ad = new admin();
                ad.Show();
                
            }
            else
            {
                MessageBox.Show("Incorrect Username or Password");
                Form1 f1 = new Form1();
                f1.Show();
            }
        }

        public void adminLogout()
        {
            Form1 f1 = new Form1();
            f1.Show();
        }
        public void admin()
        {
            Form2 f2 = new Form2();
            f2.Show();
        }
        public void viewID()
        {
            viewID vi = new viewID();
            vi.Show();
        }
        public void outFromViewID()
        {
            admin ad = new admin();
            ad.Show();
        }
    }
}
