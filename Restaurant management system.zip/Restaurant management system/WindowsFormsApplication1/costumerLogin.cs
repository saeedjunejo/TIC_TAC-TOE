﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
    class costumerLogin
    {
        public void costumer()
        {
            costumer c = new costumer();
            c.Show();
        }

        public void registration()
        {
            cocRegistration co = new cocRegistration();
            co.Show();
        }

        public void order()
        {
            order od = new order();
            od.Show();
        }

        public void costumerLogout()
        {
            Form1 f1 = new Form1();
            f1.Show();
        }

        public void details()
        {
            details dt = new details();
            dt.Show();
        }
    }
}
