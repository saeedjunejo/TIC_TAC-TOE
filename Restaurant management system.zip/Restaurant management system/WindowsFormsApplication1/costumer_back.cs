﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    class costumer_back
    {
        public void back()
        {
            Form1 f1 = new Form1();
            f1.Show();
        }

        public void back(string query)
        {
            costumer cs = new costumer();
            cs.Show();
            MessageBox.Show(query);
        }
    }
}
