﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class details : Form
    {
        public details()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                dataBaseCon db = new dataBaseCon();
                dataGridView1.DataSource = db.details("select * from costumer where password=" + textBox1.Text + "");
            }
            catch
            {
                MessageBox.Show("This password doesn't exixts in data base");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            costumerLogin cl = new costumerLogin();
            cl.order();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
