﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class pakistani : Form
    {
        public static double price = 0;
        
        public pakistani()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //pass.pakistani_total = price;
            pass.pass1 = price;
            MessageBox.Show("Your grand total for pakistani items is " + price);
            itemsClass ic = new itemsClass();
            ic.paf_back();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            itemPurchase ip = new itemPurchase();
            pass ps = new pass();
            //ps.pass1 = price;
            MessageBox.Show("Your grand total for pakistani items is "+price);
            
            itemsNew inew = new itemsNew();
            inew.done();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            itemPurchase ip = new itemPurchase();
            price = price + 110;
            ip.addItem("insert into items3(items,prices,type)values('Arabian Rice','110','pakistani')");
            
            MessageBox.Show("Arabian rice has been added\nPrice: 110 Rs");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            itemPurchase ip = new itemPurchase();
            price = price + 250;
            ip.addItem("insert into items3(items,prices,type)values('Rice n spice','250','pakistani')");

            MessageBox.Show("Rice n spice has been added\n Price: 250 Rs");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            itemPurchase ip = new itemPurchase();
            price = price + 330;
            ip.addItem("insert into items3(items,prices,type)values('Tikka Karahi','330','pakistani')");

            MessageBox.Show("Tikka Karahi has been added\n Price: 330 Rs");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            itemPurchase ip = new itemPurchase();
            price = price + 435;
            ip.addItem("insert into items3(items,prices,type)values('Sindhi Biryani','435','pakistani')");

            MessageBox.Show("Sindhi Biryani has been added\n Price: 435 Rs ");
        }
    }
}
