﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    class database2: dataBaseCon
    {
        public void add(string query)
        {
            try
            {
                SqlCommand cmd = new SqlCommand(query, getConnection());
                cmd.ExecuteNonQuery();
            }

            catch
            {
                done dd = new done();
                dd.Show();
                MessageBox.Show("Please complete entry properly...");
            }
        }
    }
}
