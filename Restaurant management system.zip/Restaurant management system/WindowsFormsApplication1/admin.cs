﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class admin : Form
    {
        public admin()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            adminLogin al = new adminLogin();
            al.viewID();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            adminLogin al = new adminLogin();
            al.adminLogout();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataBaseCon con = new dataBaseCon();
            con.getConnection();
            dataGridView1.DataSource = con.display("select * from costumer"); 
        }

        private void admin_Load(object sender, EventArgs e)
        {
            
        }
    }
}
