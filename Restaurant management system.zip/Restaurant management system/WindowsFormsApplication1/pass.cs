﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    class pass:pakistani
    {
        
        public static double pass1;
        public static void show()
        {
            
            MessageBox.Show("Reciept:\nPakistani Dishes Total:"+price);
        }

        public static void done22()
        {
            done d = new done();
            d.Show();
        }

        public static void coss()
        {
        costumer soc = new costumer();
        soc.Show();

        }
        public static void seeAll()
        {
            RECIEPTS_AND_ITEMS rec = new RECIEPTS_AND_ITEMS();
            rec.Show();
        }

        public static void admin()
        {
            admin ad = new admin();
            ad.Show();
        }

        public static void startNew()
        {
            Form1 f1 = new Form1();
            f1.Show();
        }

        //public static double pakistani_total;
        public void goo()
        {
            cocRegistration coc = new cocRegistration();
            coc.Show();
        }
    }
}
