﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    class itemPurchase:dataBaseCon
    {
        public double price = 0;
        public void addItem(string query)
        {
            SqlCommand cmd = new SqlCommand(query,getConnection());
            cmd.ExecuteNonQuery();
        }
    }
}
