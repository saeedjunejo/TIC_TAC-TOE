﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Thai : Form
    {
        public static double price = 0;
        public Thai()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your grand total for Thai items is " + price);

            itemsClass it = new itemsClass();
            it.paf_back();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            itemsNew inew = new itemsNew();
            inew.done();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            itemPurchase ip = new itemPurchase();
            price = price + 240;
            ip.addItem("insert into items3(items,prices,type)values('Tom Yung Goong','240','thai')");

            MessageBox.Show("Tom Yung Gong has been added\nPrice: 240 Rs");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            itemPurchase ip = new itemPurchase();
            price = price + 200;
            ip.addItem("insert into items3(items,prices,type)values('Gaeng Keow Wan Kai','200','pakistani')");

            MessageBox.Show("Gaeng Keow Wan Kai has been added\nPrice: 200 Rs");
        }
    }
}
