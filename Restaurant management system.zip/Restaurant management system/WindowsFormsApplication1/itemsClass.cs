﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassLibrary2;

namespace WindowsFormsApplication1
{
    class itemsClass
    {
        
        public void item()
        {
            Items it = new Items();
            it.Show();
        }

        public void pakistani()
        {
            pakistani pk = new pakistani();
            pk.Show();
        }

        public void go_back()
        {
            order od = new order();
            od.Show();
        }

        public void paf_back()
        {
            Items it = new Items();
            it.Show();
        }

        public void sea()
        {
            sea ss = new sea();
            ss.Show();
        }

        public void sea_back()
        {
            Items it = new Items();
            it.Show();
        }

        public void chinese()
        {
            Chinese ch = new Chinese();
            ch.Show();
        }

        public void thai()
        {
            Thai th = new Thai();
            th.Show();
        }

        public void finalize()
        {
            finalize fn = new finalize();
            fn.Show();
        }

        public double randomNo()
        {
            Class1 c1=new Class1();
            double num = c1.NewNumber();
            return num;
        }
    }
}
