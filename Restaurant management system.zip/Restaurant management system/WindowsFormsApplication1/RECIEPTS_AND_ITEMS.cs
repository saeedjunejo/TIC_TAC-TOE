﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class RECIEPTS_AND_ITEMS : Form
    {
        public RECIEPTS_AND_ITEMS()
        {
            InitializeComponent();
        }

        private void RECIEPTS_AND_ITEMS_Load(object sender, EventArgs e)
        {
            dataBaseCon DBC = new dataBaseCon();
            dataGridView1.DataSource= (DBC.display("Select * from finalize"));
            dataGridView2.DataSource=(DBC.display("Select * from items3"));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pass.admin();
            this.Hide();
        }
    }
}
