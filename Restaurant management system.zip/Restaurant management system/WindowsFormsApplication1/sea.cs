﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class sea : Form
    {
        public static double price = 0;
        public sea()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your grand total for Thai items is " + price);

            itemsNew inew = new itemsNew();
            inew.done();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            itemsClass ic = new itemsClass();
            ic.sea_back();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            itemPurchase ip = new itemPurchase();
            price = price + 230;
            ip.addItem("insert into items3(items,prices,type)values('Tandoori Fish','230','sea food')");

            MessageBox.Show("Tandoori Fish has been added\nPrice: 230 Rs");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            itemPurchase ip = new itemPurchase();
            price = price + 130;
            ip.addItem("insert into items3(items,prices,type)values('Grill veg fish','110','sea food')");

            MessageBox.Show("Grill vegetable Fish has been added\nPrice: 130 Rs");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            itemPurchase ip = new itemPurchase();
            price = price + 150;
            ip.addItem("insert into items3(items,prices,type)values('Fish puffs','150','sea food')");

            MessageBox.Show("Friday Fish puff has been added\nPrice: 150 Rs");
        }
    }
}
