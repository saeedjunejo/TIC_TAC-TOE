﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication1
{
    public partial class costumer : Form
    {
        public costumer()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            costumerLogin cl = new costumerLogin();
            cl.registration();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataBaseCon dbc = new dataBaseCon();
            SqlCommand cmd = new SqlCommand("select * from costumer where name='" + textBox1.Text + "' and password='" + textBox2.Text + "'",dbc.getConnection());

            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {


                costumerLogin cl = new costumerLogin();
                cl.order();
                this.Hide();
            }
            else
            {
                MessageBox.Show("ID OR PASSWORD IS INCORRECT");
            }
  

        }

        private void button3_Click(object sender, EventArgs e)
        {
            costumer_back cb = new costumer_back();
            cb.back();
            this.Hide();
        }
    }
}
