﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            string name = textBox1.Text;
            string password = textBox2.Text;
            adminLogin al = new adminLogin();
            al.UserName = textBox1.Text;
            al.Password = textBox2.Text;

            al.login();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            admin_back ab = new admin_back();
            ab.back();
            this.Hide();
        }
    }
}
