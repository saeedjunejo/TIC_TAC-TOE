﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class cocRegistration : Form
    {
        public cocRegistration()
        {
            InitializeComponent();
        }

        private void cocRegistration_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                dataBaseCon con = new dataBaseCon();
                con.getConnection();
                con.addCos("Insert into costumer(name,contactNo,address,email,password)values('" + textBox1.Text + "'," + textBox2.Text + ",'" + textBox3.Text + "','" + textBox4.Text + "'," + textBox5.Text + ")");
                MessageBox.Show("You are successfully registered");
                pass.coss();
                this.Hide();
            }
            catch
            {
                MessageBox.Show("Some thing went wrong or Password already exist... \nTry Again");
                pass p = new pass();
                p.goo();
                this.Hide();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            costumer_back sb = new costumer_back();
            sb.back("you are not registered");
            this.Hide();
        }
    }
}
