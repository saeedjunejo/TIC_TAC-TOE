﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;


namespace WindowsFormsApplication1
{
    class dataBaseCon
    {
        SqlConnection con;
        public SqlConnection getConnection()
        {
            con = new SqlConnection(@"server=JAMIL\JAMIL;database=project;integrated security=true;");
            con.Open();
            return con;
        }

        public DataTable display(string query)
        {
            SqlDataAdapter adp = new SqlDataAdapter(query,getConnection());
            DataTable dt = new DataTable();
            adp.Fill(dt);
            return dt;
        }

        public void addCos(string query)
        {
            try
            {
                SqlCommand cmd = new SqlCommand(query, getConnection());
                cmd.ExecuteNonQuery();
            }
            catch
            {
                MessageBox.Show("Sorry invalid entry... Try Again");
            }
        }

        public DataTable search(string ty, string tz)
        {
            try
            {
                SqlDataAdapter adp = null;
                if (ty == "id")
                {
                    adp = new SqlDataAdapter("select * from costumer where id=" + tz + "", getConnection());
                }
                else if (ty == "name")
                {
                    adp = new SqlDataAdapter("select * from costumer where name='" + tz + "'", getConnection());
                }
                else if (ty == "address")
                {
                    adp = new SqlDataAdapter("select * from costumer where address='" + tz + "'", getConnection());
                }
                else
                {
                    MessageBox.Show("Invalid entry..");
                }
                DataTable dt = new DataTable();
                adp.Fill(dt);
                return dt;
            }
            catch
            {
                MessageBox.Show("Invalid entry");
                return null;
            }
        }

        public DataTable details(string query)
        {
            SqlDataAdapter adp = new SqlDataAdapter(query,getConnection());
            DataTable dt = new DataTable();
            adp.Fill(dt);
            return dt;
        }
    }
}
