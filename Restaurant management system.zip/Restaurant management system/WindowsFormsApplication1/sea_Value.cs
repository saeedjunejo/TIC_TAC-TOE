﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    class sea_Value:sea
    {
        public static void show()
        {
            MessageBox.Show(""+price);
        }
    }
}
