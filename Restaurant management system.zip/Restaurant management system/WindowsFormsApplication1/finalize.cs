﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class finalize : Form
    {
        public finalize()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataBaseCon db = new dataBaseCon();
            dataGridView1.DataSource= db.display("select * from finalize where recieptID="+textBox1.Text+"");
            double ans = pass.price + sea_Value.price + chinese_Value.price + Thai_Value.price;
            label3.Text=" PRICE INFORMATION:\n\nGrand total for Pakistani Items: "+pass.price+"\nGrand total for Sea Food Items: "+sea_Value.price+"\nGrand total for Chinese Items: "+chinese_Value.price+"\nGrand total for Thai Food Items: "+Thai_Value.price+"\n\nFinal Grand Total: "+ans;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pass.done22();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pass.startNew();
            this.Hide();

        }
    } 
}