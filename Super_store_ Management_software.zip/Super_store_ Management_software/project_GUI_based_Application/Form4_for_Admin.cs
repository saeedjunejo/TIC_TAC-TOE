﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace project_GUI_based_Application
{
    public partial class Form4_for_Admin : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=JAMIL\JAMIL;Initial Catalog=project_GUI_based_Application;Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter adapter;
        int id = 0;
        public Form4_for_Admin()
        {
            InitializeComponent();
        }
        private void clear()
        {
            con.Open();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            id = 0;
            con.Close();
        }
        public void display()
        {

            con.Open();
            DataTable dt = new DataTable();
            adapter = new SqlDataAdapter("SELECT * FROM ADMINS", con);
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form4_for_Admin_Load(object sender, EventArgs e)
        {
            display();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("insert_into_admins", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name", SqlDbType.NVarChar).Value = textBox1.Text.Trim();
                cmd.Parameters.AddWithValue("@pass", SqlDbType.NVarChar).Value = textBox2.Text.Trim();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("data inserted successfully");
                display();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (id != 0)
                {
                    cmd = new SqlCommand("delete from admins where admin_id = @id", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Deleted Successfully", "delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    display();
                    clear();
                }

                else
                {
                    MessageBox.Show("Something went wrong try again..");
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
                {

                    cmd = new SqlCommand("update admins set admin_name=@name,admin_password=@pass where admin_id=@id", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@name", textBox1.Text);
                    cmd.Parameters.AddWithValue("@pass", textBox2.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Values updated successfully");
                    display();
                    clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            finalize_for_admins ad = new finalize_for_admins();
            ad.Show();
            this.Hide();
        }
    }
}
