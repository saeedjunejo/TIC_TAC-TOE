﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace project_GUI_based_Application
{
    public partial class Form10_for_salariescs : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=JAMIL\JAMIL;Initial Catalog=project_GUI_based_Application;Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter adapter;
        int id = 0;
        public Form10_for_salariescs()
        {
            InitializeComponent();
        }
        private void clear()
        {
            con.Open();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            id = 0;
            con.Close();
        }
        public void display()
        {
            con.Open();
            DataTable dt = new DataTable();
            adapter = new SqlDataAdapter("select * from salaries", con);
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
        private void Form10_for_salariescs_Load(object sender, EventArgs e)
        {
            clear();
            display();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("insert_into_salaries", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@emp", SqlDbType.Int).Value = textBox1.Text.Trim();
                cmd.Parameters.AddWithValue("@amount", SqlDbType.BigInt).Value = textBox2.Text.Trim();
                cmd.Parameters.AddWithValue("@section", SqlDbType.Int).Value = textBox3.Text.Trim();
                cmd.Parameters.AddWithValue("@mos", SqlDbType.NVarChar).Value = textBox4.Text.Trim();
                cmd.Parameters.AddWithValue("@adminID", SqlDbType.Int).Value = textBox5.Text.Trim();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("data inserted successfully");
                display();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (id != 0)
                {
                    cmd = new SqlCommand("delete from salaries where salary_id = @id", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Deleted Successfully", "delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    display();
                    clear();
                }

                else
                {
                    MessageBox.Show("Something went wrong try again..");
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            textBox5.Text = dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
            textBox6.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            textBox7.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            textBox8.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to update", "update", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "")
                    {

                        cmd = new SqlCommand("update salaries set employee_id=@emp,amount=@amount,section_id=@section,date=@date,month_of_salary=@month where salary_id=@id", con);
                        con.Open();
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.Parameters.AddWithValue("@emp", textBox1.Text);
                        cmd.Parameters.AddWithValue("@amount", textBox2.Text);
                        cmd.Parameters.AddWithValue("@section", textBox3.Text);
                        cmd.Parameters.AddWithValue("@date", textBox7.Text);
                        cmd.Parameters.AddWithValue("@month", textBox4.Text);
                        cmd.ExecuteNonQuery();
                        con.Close();
                        MessageBox.Show("Values updated successfully");
                        display();
                        clear();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            finalize_for_salaries dd = new finalize_for_salaries();
            dd.Show();
            this.Hide();
        }
    }
}
