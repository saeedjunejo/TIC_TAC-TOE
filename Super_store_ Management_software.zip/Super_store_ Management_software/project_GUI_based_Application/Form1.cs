﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace project_GUI_based_Application
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=JAMIL\JAMIL;Initial Catalog=project_GUI_based_Application;Integrated Security=True");
        string tableName;
        SqlDataAdapter adapter;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void display(string table)
        {
            tableName = table;
            if (table == "PURCHASES")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select p.purchase_id,p.quantity,p.date,p.remarks,p.timestamp,a.admin_name,s.supplier_name,i.item_name,p.sale_price from purchases as p join admins as a on p.admin_ID=a.admin_id join suppliers as s on p.supplier_id=s.supplier_id join items as i on p.item_id=i.item_id", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }

            else if(table=="SALES")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select s.sale_id,s.quantity,s.date,s.cost,s.timestamp,a.admin_name,p.quantity,c.customer_name from sales as s join admins as a on s.admin_ID=a.admin_id join purchases as p on s.purchase_id=p.purchase_id join customers as c on s.costumer_id=c.customer_id", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if (table=="ITEMS")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select i.item_id,i.item_name,i.remark,i.timestamp,a.admin_name from items as i join admins as a on i.admin_ID=a.admin_id", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if (table=="EXPANSES")
            {

                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select e.expense_id,e.expense_name,e.expense_amount,e.date,e.timestamp,a.admin_name from expenses as e join admins as a on e.admin_ID=a.admin_id", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if (table=="CUSTOMERS")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select c.customer_id,c.customer_name,c.customer_mobile,c.customer_address,c.customer_email,c.timestamp,a.admin_name from customers as c join admins as a on c.admin_ID=a.admin_id", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if (table=="SECTIONS")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select s.section_id,s.section_name,s.section_description,s.timestamp,a.admin_name from section as s join admins as a on s.admin_ID=a.admin_id", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if (table=="SALARIES")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select s.salary_id,s.amount,s.date,s.month_of_salary,s.timestamp,a.admin_name,e.employee_name,w.section_name from salaries as s join admins as a on s.admin_ID=a.admin_id join employees as e on s.employee_id=e.employee_id join section as w on s.section_id=w.section_id", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if (table=="EMPLOYEES")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select e.employee_id,e.employee_name,e.employee_salary,e.employee_address,e.employee_designation,e.join_date,e.dob,e.timestamp,s.section_name,a.admin_name from employees as e join admins as a on e.admin_ID=a.admin_id join section as s on e.section_id=s.section_id", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if (table=="SUPPLIERS")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select s.supplier_id,s.supplier_name,s.supplier_address,s.supplier_phone,s.supplier_email,s.timestamp,a.admin_name from suppliers as s join admins as a on s.admin_ID=a.admin_id", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if(table=="ADMIN")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("SELECT * FROM ADMINS", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            display(button2.Text);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            final_login FL = new final_login();
            FL.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            display(button1.Text);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            display(button11.Text);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            display(button6.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            display(button3.Text);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            display(button4.Text);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            display(button5.Text);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            display(button7.Text);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            display(button8.Text);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            display(button9.Text);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            string searchVar = Convert.ToString(textBox1.Text);
            if (tableName=="SALES")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select s.sale_id,s.quantity,s.date,s.cost,s.timestamp,a.admin_name,p.quantity,c.customer_name from sales as s join admins as a on s.admin_ID=a.admin_id join purchases as p on s.purchase_id=p.purchase_id join customers as c on s.costumer_id=c.customer_id where s.sale_id like '%" + searchVar + "%' or s.quantity like '%" + searchVar + "%' or s.date  like '%" + searchVar + "%' or s.cost  like '%" + searchVar + "%' or s.timestamp like '%" + searchVar + "%' or a.admin_name  like '%" + searchVar + "%' or p.quantity  like '%" + searchVar + "%' or c.customer_name like '%" + searchVar + "%'", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if (tableName=="PURCHASES")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select p.purchase_id,p.quantity,p.date,p.remarks,p.timestamp,a.admin_name,s.supplier_name,i.item_name from purchases as p join admins as a on p.admin_ID=a.admin_id join suppliers as s on p.supplier_id=s.supplier_id join items as i on p.item_id=i.item_id where p.purchase_id like '%" + searchVar + "%' or p.quantity like '%" + searchVar + "%' or p.date like '%" + searchVar + "%' or p.remarks like '%" + searchVar + "%' or p.timestamp like '%" + searchVar + "%' or a.admin_name like '%" + searchVar + "%' or s.supplier_name like '%" + searchVar + "%' or i.item_name like '%" + searchVar + "%'", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if (tableName=="ITEMS")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select i.item_id,i.item_name,i.remark,i.timestamp,a.admin_name from items as i join admins as a on i.admin_ID=a.admin_id where i.item_id='"+textBox1.Text+"'", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if (tableName=="EXPANSES")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select e.expense_id,e.expense_name,e.expense_amount,e.date,e.timestamp,a.admin_name from expenses as e join admins as a on e.admin_ID=a.admin_id where  e.expense_id='"+textBox1.Text+"'", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if (tableName=="CUSTOMERS")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select c.customer_id,c.customer_name,c.customer_mobile,c.customer_address,c.customer_email,c.timestamp,a.admin_name from customers as c join admins as a on c.admin_ID=a.admin_id where c.customer_id='"+textBox1.Text+"'", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if (tableName=="SECTIONS")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select s.section_id,s.section_name,s.section_description,s.timestamp,a.admin_name from section as s join admins as a on s.admin_ID=a.admin_id where s.section_id = '"+textBox1.Text+"'", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if (tableName=="SALARIES")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select s.salary_id,s.amount,s.date,s.month_of_salary,s.timestamp,a.admin_name,e.employee_name,w.section_name from salaries as s join admins as a on s.admin_ID=a.admin_id join employees as e on s.employee_id=e.employee_id join section as w on s.section_id=w.section_id where s.salary_id='"+textBox1.Text+"'", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if (tableName=="EMPLOYEES")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select e.employee_id,e.employee_name,e.employee_salary,e.employee_address,e.employee_designation,e.join_date,e.dob,e.timestamp,s.section_name,a.admin_name from employees as e join admins as a on e.admin_ID=a.admin_id join section as s on e.section_id=s.section_id where e.employee_id='"+textBox1.Text+"'", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if (tableName=="SUPPLIERS")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select s.supplier_id,s.supplier_name,s.supplier_phone,s.supplier_email,s.timestamp,a.admin_name from suppliers as s join admins as a on s.admin_ID=a.admin_id where s.supplier_id= '"+textBox1.Text+"'", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if (tableName=="ADMIN")
            {
                con.Open();
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter("select * from admins where admin_id like '%" + textBox1.Text + "%' or admin_name like '%" + textBox1.Text + "%' or admin_password like'%" + textBox1.Text + "%'", con);
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else
            {
                MessageBox.Show("No table Found");
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            admin_form a = new admin_form();
            a.Show();
        }

        private void button13_Click_1(object sender, EventArgs e)
        {
            if (tableName=="PURCHASES")
            {
                Form2_add_button f2 = new Form2_add_button();
                f2.Show();
                this.Hide();
            }
            else if (tableName=="SALES")
            {
                Form3_for_sales sales = new Form3_for_sales();
                sales.Show();
                this.Hide();
            }
            else if (tableName=="SUPPLIERS")
            {
                Formr4_for_suppliar f4 = new Formr4_for_suppliar();
                f4.Show();
                this.Hide();
            }
            else if (tableName=="ADMIN")
            {
                Form4_for_Admin admin = new Form4_for_Admin();
                admin.Show();
                this.Hide();
            }
            else if (tableName=="ITEMS")
            {
                Form6_for_items items = new Form6_for_items();
                items.Show();
                this.Hide();
            }
            else if (tableName=="EXPANSES")
            {
                Form7_for_expenses exp = new Form7_for_expenses();
                exp.Show();
                this.Hide();
            }
            else if (tableName=="CUSTOMERS")
            {
                Form8_for_customers f8 = new Form8_for_customers();
                f8.Show();
                this.Hide();
            }
            else if (tableName=="SECTIONS")
            {
                Form9_for_sections f9 = new Form9_for_sections();
                f9.Show();
                this.Hide();
            }
            else if (tableName=="SALARIES")
            {
                Form10_for_salariescs f10 = new Form10_for_salariescs();
                f10.Show();
                this.Hide();
            }
            else if (tableName=="EMPLOYEES")
            {
                Form11_for_emp f11 = new Form11_for_emp();
                f11.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("table not found");
            }
            
        }
    }
}


