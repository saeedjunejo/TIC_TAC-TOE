﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace project_GUI_based_Application
{
    public partial class Form8_for_customers : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=JAMIL\JAMIL;Initial Catalog=project_GUI_based_Application;Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter adapter;
        int id = 0;
        public Form8_for_customers()
        {
            InitializeComponent();
        }
        private void clear()
        {
            con.Open();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            id = 0;
            con.Close();
        }
        public void display()
        {
            con.Open();
            DataTable dt = new DataTable();
            adapter = new SqlDataAdapter("select * from customers", con);
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void Form8_for_customers_Load(object sender, EventArgs e)
        {
            clear();
            display();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("insert_into_customers", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name", SqlDbType.NVarChar).Value = textBox1.Text.Trim();
                cmd.Parameters.AddWithValue("@mobile", SqlDbType.NVarChar).Value = textBox2.Text.Trim();
                cmd.Parameters.AddWithValue("@address", SqlDbType.NVarChar).Value = textBox3.Text.Trim();
                cmd.Parameters.AddWithValue("@email", SqlDbType.NVarChar).Value = textBox4.Text.Trim();
                cmd.Parameters.AddWithValue("@adminID", SqlDbType.Int).Value = textBox5.Text.Trim();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("data inserted successfully");
                display();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (id != 0)
            {
                cmd = new SqlCommand("delete from customers where customer_id = @id", con);
                con.Open();
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Deleted Successfully", "delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                display();
                clear();
            }

            else
            {
                MessageBox.Show("Something went wrong try again..");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            textBox5.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
            textBox6.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            textBox7.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to update", "update", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "" && textBox6.Text != "" && textBox7.Text != "")
                    {
                        cmd = new SqlCommand("update customers set customer_name=@name,customer_mobile=@mob,customer_address=addr,customer_email=@email where customer_id=@id", con);
                        con.Open();
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.Parameters.AddWithValue("@name", textBox1.Text);
                        cmd.Parameters.AddWithValue("@mob", textBox2.Text);
                        cmd.Parameters.AddWithValue("@addr", textBox3.Text);
                        cmd.Parameters.AddWithValue("@email", textBox4.Text);
                        cmd.ExecuteNonQuery();
                        con.Close();
                        MessageBox.Show("Values updated successfully");
                        display();
                        clear();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            finalize_for_customer c = new finalize_for_customer();
            c.Show();
            this.Hide();
        }
    }
}
