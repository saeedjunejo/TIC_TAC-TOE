﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace project_GUI_based_Application
{
    public partial class purchases_finalize : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=JAMIL\JAMIL;Initial Catalog=project_GUI_based_Application;Integrated Security=True");
        SqlCommand cmd;

        public purchases_finalize()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2_add_button f2 = new Form2_add_button();
            f2.Show();
            this.Hide();
        }
        public void display()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("display_proc",con);
            cmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void purchases_finalize_Load(object sender, EventArgs e)
        {
            display();
        }
    }
}
