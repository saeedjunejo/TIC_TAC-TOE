﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace project_GUI_based_Application
{
    public partial class form_for_admin_login : Form
    {
        public form_for_admin_login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text=="jamil raza khan" && textBox2.Text=="123")
            {
                Form1 f1 = new Form1();
                f1.Show();
                this.Hide();
            }
            else if (textBox1.Text=="rizwan ahmed junejo" && textBox2.Text=="1234")
            {
                Form1 f1 = new Form1();
                f1.Show();
                this.Hide();
            }
            else if (textBox1.Text=="huzaifa hussain" && textBox2.Text=="abc")
            {
                Form1 f1 = new Form1();
                f1.Show();
                this.Hide();
            }

            else
            {
                MessageBox.Show("Invalid admin name or password");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(1);
        }
    }
}
