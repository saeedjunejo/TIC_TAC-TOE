﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace project_GUI_based_Application
{
    public partial class Formr4_for_suppliar : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=JAMIL\JAMIL;Initial Catalog=project_GUI_based_Application;Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter adapter;
        int id = 0;
        public Formr4_for_suppliar()
        {
            InitializeComponent();
        }
        public void display()
        {
            con.Open();
            DataTable dt = new DataTable();
            adapter = new SqlDataAdapter("select * from suppliers", con);
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void clear()
        {
            con.Open();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            id = 0;
            con.Close();
        }

        private void Formr4_for_suppliar_Load(object sender, EventArgs e)
        {
            clear();
            display();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("insert_into_suppliers", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name", SqlDbType.NVarChar).Value = textBox1.Text.Trim();
                cmd.Parameters.AddWithValue("@address", SqlDbType.NVarChar).Value = textBox2.Text.Trim();
                cmd.Parameters.AddWithValue("@phone", SqlDbType.NVarChar).Value = textBox3.Text.Trim();
                cmd.Parameters.AddWithValue("@email", SqlDbType.NVarChar).Value = textBox4.Text.Trim();
                cmd.Parameters.AddWithValue("@adminID", SqlDbType.Int).Value = textBox5.Text.Trim();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("data inserted successfully");
                display();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (id != 0)
            {
                cmd = new SqlCommand("delete from suppliers where supplier_id = @id", con);
                con.Open();
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Deleted Successfully", "delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                display();
                clear();
            }

            else
            {
                MessageBox.Show("Something went wrong try again..");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            textBox5.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
            textBox6.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            textBox7.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "" && textBox6.Text != "" && textBox7.Text != "")
                {

                    cmd = new SqlCommand("update suppliers set supplier_name=@name,supplier_address=@address,supplier_phone=@phone,supplier_email=@mail,timestamp=@time,admin_ID=@a_id where supplier_id=@id", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@name", textBox1.Text);
                    cmd.Parameters.AddWithValue("@time", textBox7.Text);
                    cmd.Parameters.AddWithValue("@address", textBox2.Text);
                    cmd.Parameters.AddWithValue("@phone", textBox3.Text);
                    cmd.Parameters.AddWithValue("@mail", textBox4.Text);
                    cmd.Parameters.AddWithValue("@a_id", textBox5.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Values updated successfully");
                    display();
                    clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            finalize_for_suppliers ii = new finalize_for_suppliers();
            ii.Show();
            this.Hide();
        }
    }
}
