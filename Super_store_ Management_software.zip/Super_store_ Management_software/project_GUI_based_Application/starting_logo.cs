﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace project_GUI_based_Application
{
    public partial class starting_logo : Form
    {
        public starting_logo()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            final_login final = new final_login();
            final.Show();
            this.Hide();
        }
    }
}
