﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace project_GUI_based_Application
{
    public partial class finalize_for_admins : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=JAMIL\JAMIL;Initial Catalog=project_GUI_based_Application;Integrated Security=True");
        SqlCommand cmd;
        public finalize_for_admins()
        {
            InitializeComponent();
        }
        public void display()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("display_admin", con);
            cmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form4_for_Admin F4 = new Form4_for_Admin();
            F4.Show();
            this.Hide();
        }

        private void finalize_for_admins_Load(object sender, EventArgs e)
        {
            display();
        }
    }
}
