﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car_showroom_winapp
{
    public partial class add_costumer : Form
    {
        public add_costumer()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CUSTOMER AD = new CUSTOMER()
            {
                Customer_name = textBox2.Text,
                Customer_number = textBox3.Text,
                Address =textBox1.Text,
            };
            AD.ADD();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CUSTOMER cs = new CUSTOMER() {

                Customer_name = textBox2.Text
            };
            cs.Delete();
        }
    }
}
