﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car_showroom_winapp
{
    public partial class Sold_and_Unsold_Cars : Form
    {
        public Sold_and_Unsold_Cars()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (Unsoldchk_box.Checked)
            {
                Soldchk_box.Checked = false;
                SqlDataAdapter adpt = new SqlDataAdapter("select * from tbl_cars where Type = 'In'", Connection.Get());
                DataTable dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else if (Soldchk_box.Checked)
            {
                Unsoldchk_box.Checked = false;
                SqlDataAdapter adpt = new SqlDataAdapter("select * from tbl_cars where Type != 'In'", Connection.Get());
                DataTable dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else
            {
                MessageBox.Show("Please Select First");
            }


        }

        private void Soldchk_box_CheckedChanged(object sender, EventArgs e)
        {

           if (Soldchk_box.Checked)
            {
                Unsoldchk_box.Checked = false;
            }
        }

        private void Unsoldchk_box_CheckStateChanged(object sender, EventArgs e)
        {
            if (Unsoldchk_box.Checked)
            {
                Soldchk_box.Checked = false;
            }
        }

        private void EXIT_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
