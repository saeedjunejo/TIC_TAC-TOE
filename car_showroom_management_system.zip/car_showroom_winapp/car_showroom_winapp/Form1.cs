﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car_showroom_winapp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            add_car add_newcar = new add_car();
            add_newcar.Show();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            add_costumer ad = new add_costumer();
            ad.Show();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
                
        }

        private void button2_Click(object sender, EventArgs e)
        {
            EDIT_CAR edit = new EDIT_CAR();
            edit.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CARS_LIST cl = new CARS_LIST();
            cl.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Sold_and_Unsold_Cars sc = new Sold_and_Unsold_Cars();
            sc.Show();
            
        }
    }
}
