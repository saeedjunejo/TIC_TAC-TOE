﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car_showroom_winapp
{
    public partial class CARS_LIST : Form
    {
        public CARS_LIST()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void CARS_LIST_Load(object sender, EventArgs e)
        {
            SqlDataAdapter adpt = new SqlDataAdapter("select * from tbl_cars", Connection.Get());
            DataTable dt = new DataTable();
            adpt.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
