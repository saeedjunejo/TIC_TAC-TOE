﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace car_showroom_winapp
{
   
   public  class ADDNEW_CAR
    {
        public string Make { get; set; }
        public int Model { get; set; }
        public string Chasis { get; set; }
        public string Colour { get; set; }
        public string Kms { get; set; }
        public string Address { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public decimal Cost { get; set; }
        public string Type { get; set; }
        public decimal Profit { get; set; }

        public string date = DateTime.Now.ToString("MM/dd/yyyy h:mm tt");

        public void ADD()
        {
            
            string query = "insert into tbl_Cars values('" + Make + "','" + Model + "','" + Chasis + "','" + Colour + "','" + Kms + "','" +Address + "','" +Description + "','" + Price + "','" + Cost + "','" + Type + "','" + Profit + "','" + date + "') ";
            SqlCommand SC = new SqlCommand(query, Connection.Get());
            SC.ExecuteNonQuery();
            
        }
        public void EDIT()
        {

            string query = "Update tbl_Cars set Make ='" + Make + "',Model ='" + Model + "',Colour ='" + Colour + "',Kms ='" + Kms + "',Address ='" + Address + "',Description ='" + Description + "',Price ='" + Price + "',Cost ='" + Cost + "',Type ='" + Type + "',Profit ='" + Profit + "',Date ='" + date + "' where Chasis = '"+Chasis+"'";
            SqlCommand SC = new SqlCommand(query, Connection.Get());
            SC.ExecuteNonQuery();

        }
        public void Delete()
        {
            string query = "delete tbl_Cars where Chasis ='" + Chasis + "'";
            SqlCommand SC = new SqlCommand(query, Connection.Get());
            SC.ExecuteNonQuery();

        }

        public ADDNEW_CAR Search()
        {
            string query = "EXEC SPSHOWTBLE @Chasis = '" + Chasis + "'";
            SqlCommand SC = new SqlCommand(query, Connection.Get());
            SC.ExecuteNonQuery();
            ADDNEW_CAR b = new ADDNEW_CAR();
            SqlDataReader sdr = SC.ExecuteReader();
            while (sdr.Read())
            {
                b.Make = (string)sdr["Make"];
                b.Model = (int)sdr["Model"];
                b.Chasis = (string)sdr["Chasis"];
                b.Colour = (string)sdr["Colour"];
                b.Kms = (string)sdr["Kms"];
                b.Address = (string)sdr["Address"];
                b.Description = (string)sdr["Description"];
                b.Price = (decimal)sdr["Price"];
                b.Cost = (decimal)sdr["Cost"];
                b.Type = (string)sdr["Type"];
                b.Profit = (decimal)sdr["Profit"];
              

            }
            sdr.Close();
            return b;
        }
    }

   
}
