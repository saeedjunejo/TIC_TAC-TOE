﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace car_showroom_winapp
{
    class Connection
    {
     
        static SqlConnection Sc;
        public static SqlConnection Get()
        {
            if (Sc == null)
            {
                Sc = new SqlConnection();
                Sc.ConnectionString = @"Data Source=DESKTOP-EQNOCP0\SQLEXPRESS; Initial Catalog=Car_Showroom; Integrated Security=True";
                Sc.Open();

            }
            return Sc;

        }
  
    }
}
