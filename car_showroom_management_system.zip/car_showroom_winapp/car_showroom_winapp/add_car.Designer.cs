﻿namespace car_showroom_winapp
{
    partial class add_car
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Make_txt = new System.Windows.Forms.TextBox();
            this.Model_txt = new System.Windows.Forms.TextBox();
            this.Chasis_txt = new System.Windows.Forms.TextBox();
            this.Colour_txt = new System.Windows.Forms.TextBox();
            this.Kms_txt = new System.Windows.Forms.TextBox();
            this.Address_txt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Description_txt = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.Cost_txt = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.lbldate = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.type_txt = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Make_txt
            // 
            this.Make_txt.Location = new System.Drawing.Point(153, 25);
            this.Make_txt.Name = "Make_txt";
            this.Make_txt.Size = new System.Drawing.Size(126, 20);
            this.Make_txt.TabIndex = 0;
            // 
            // Model_txt
            // 
            this.Model_txt.Location = new System.Drawing.Point(153, 60);
            this.Model_txt.Name = "Model_txt";
            this.Model_txt.Size = new System.Drawing.Size(126, 20);
            this.Model_txt.TabIndex = 1;
            // 
            // Chasis_txt
            // 
            this.Chasis_txt.Location = new System.Drawing.Point(153, 95);
            this.Chasis_txt.Name = "Chasis_txt";
            this.Chasis_txt.Size = new System.Drawing.Size(126, 20);
            this.Chasis_txt.TabIndex = 2;
            // 
            // Colour_txt
            // 
            this.Colour_txt.Location = new System.Drawing.Point(153, 130);
            this.Colour_txt.Name = "Colour_txt";
            this.Colour_txt.Size = new System.Drawing.Size(126, 20);
            this.Colour_txt.TabIndex = 3;
            // 
            // Kms_txt
            // 
            this.Kms_txt.Location = new System.Drawing.Point(153, 165);
            this.Kms_txt.Name = "Kms_txt";
            this.Kms_txt.Size = new System.Drawing.Size(126, 20);
            this.Kms_txt.TabIndex = 4;
            // 
            // Address_txt
            // 
            this.Address_txt.Location = new System.Drawing.Point(153, 201);
            this.Address_txt.Name = "Address_txt";
            this.Address_txt.Size = new System.Drawing.Size(126, 20);
            this.Address_txt.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(65, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Make";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(65, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Model";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(65, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Colour";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(65, 172);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Kms";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(65, 207);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Address";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(65, 245);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Discription";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(65, 102);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Chasis";
            // 
            // Description_txt
            // 
            this.Description_txt.Location = new System.Drawing.Point(153, 238);
            this.Description_txt.Name = "Description_txt";
            this.Description_txt.Size = new System.Drawing.Size(126, 20);
            this.Description_txt.TabIndex = 13;
            this.Description_txt.Text = "  ";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(234, 390);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(113, 28);
            this.button2.TabIndex = 15;
            this.button2.Text = "SAVE";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Cost_txt
            // 
            this.Cost_txt.Location = new System.Drawing.Point(153, 274);
            this.Cost_txt.Name = "Cost_txt";
            this.Cost_txt.Size = new System.Drawing.Size(126, 20);
            this.Cost_txt.TabIndex = 16;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(234, 424);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 28);
            this.button1.TabIndex = 18;
            this.button1.Text = "BACK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(69, 371);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(30, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "Date";
            // 
            // lbldate
            // 
            this.lbldate.AutoSize = true;
            this.lbldate.Location = new System.Drawing.Point(150, 371);
            this.lbldate.Name = "lbldate";
            this.lbldate.Size = new System.Drawing.Size(30, 13);
            this.lbldate.TabIndex = 20;
            this.lbldate.Text = "Date";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(68, 281);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(28, 13);
            this.label10.TabIndex = 22;
            this.label10.Text = "Cost";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(65, 318);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(31, 13);
            this.label11.TabIndex = 24;
            this.label11.Text = "Type";
            // 
            // type_txt
            // 
            this.type_txt.Location = new System.Drawing.Point(153, 311);
            this.type_txt.Name = "type_txt";
            this.type_txt.Size = new System.Drawing.Size(126, 20);
            this.type_txt.TabIndex = 23;
            this.type_txt.Text = "In";
            // 
            // add_car
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(481, 455);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.type_txt);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lbldate);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Cost_txt);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Description_txt);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Address_txt);
            this.Controls.Add(this.Kms_txt);
            this.Controls.Add(this.Colour_txt);
            this.Controls.Add(this.Chasis_txt);
            this.Controls.Add(this.Model_txt);
            this.Controls.Add(this.Make_txt);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.HelpButton = true;
            this.MaximumSize = new System.Drawing.Size(481, 455);
            this.MinimumSize = new System.Drawing.Size(481, 455);
            this.Name = "add_car";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.add_car_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Make_txt;
        private System.Windows.Forms.TextBox Model_txt;
        private System.Windows.Forms.TextBox Chasis_txt;
        private System.Windows.Forms.TextBox Colour_txt;
        private System.Windows.Forms.TextBox Kms_txt;
        private System.Windows.Forms.TextBox Address_txt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Description_txt;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox Cost_txt;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbldate;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox type_txt;
    }
}