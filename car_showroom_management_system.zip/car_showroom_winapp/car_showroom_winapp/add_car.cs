﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car_showroom_winapp
{
    public partial class add_car : Form
    {
        public add_car()
        {
            InitializeComponent();
        }

        private void add_car_Load(object sender, EventArgs e)
        {
            lbldate.Text = DateTime.Now.ToString("MM/dd/yyyy h:mm tt");
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            Form1 f1 = new Form1();
            this.Hide();
            f1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {


                ADDNEW_CAR A_C = new ADDNEW_CAR()
                {

                    Make = Make_txt.Text,
                    Model = Convert.ToInt32(Model_txt.Text),
                    Chasis = Chasis_txt.Text,
                    Colour = Colour_txt.Text,
                    Kms = Kms_txt.Text,
                    Address = Address_txt.Text,
                    Description = Description_txt.Text,
                    Cost = Convert.ToDecimal(Cost_txt.Text),
                    Type = type_txt.Text,


                };
                A_C.ADD();
                MessageBox.Show("Car Record Added");

            }

            catch (Exception )
            {
                if (Chasis_txt.Text == "" )
                {
                    MessageBox.Show("Plesase Enter in a Correct Format");
                    this.Refresh();
                }
               
            }
        }
    }
}
