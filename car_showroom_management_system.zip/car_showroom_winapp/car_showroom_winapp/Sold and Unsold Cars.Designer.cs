﻿namespace car_showroom_winapp
{
    partial class Sold_and_Unsold_Cars
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Soldchk_box = new System.Windows.Forms.CheckBox();
            this.Unsoldchk_box = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.EXIT_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(2, 60);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1139, 320);
            this.dataGridView1.TabIndex = 0;
            // 
            // Soldchk_box
            // 
            this.Soldchk_box.AutoSize = true;
            this.Soldchk_box.Location = new System.Drawing.Point(390, 33);
            this.Soldchk_box.Name = "Soldchk_box";
            this.Soldchk_box.Size = new System.Drawing.Size(71, 17);
            this.Soldchk_box.TabIndex = 1;
            this.Soldchk_box.Text = "Sold Cars";
            this.Soldchk_box.UseVisualStyleBackColor = true;
            this.Soldchk_box.CheckedChanged += new System.EventHandler(this.Soldchk_box_CheckedChanged);
            // 
            // Unsoldchk_box
            // 
            this.Unsoldchk_box.AutoSize = true;
            this.Unsoldchk_box.Location = new System.Drawing.Point(467, 35);
            this.Unsoldchk_box.Name = "Unsoldchk_box";
            this.Unsoldchk_box.Size = new System.Drawing.Size(83, 17);
            this.Unsoldchk_box.TabIndex = 2;
            this.Unsoldchk_box.Text = "Unsold Cars";
            this.Unsoldchk_box.UseVisualStyleBackColor = true;
            this.Unsoldchk_box.CheckStateChanged += new System.EventHandler(this.Unsoldchk_box_CheckStateChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(582, 31);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(133, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "Show Record";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // EXIT_btn
            // 
            this.EXIT_btn.BackColor = System.Drawing.Color.Gray;
            this.EXIT_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EXIT_btn.Location = new System.Drawing.Point(1000, 398);
            this.EXIT_btn.Name = "EXIT_btn";
            this.EXIT_btn.Size = new System.Drawing.Size(75, 23);
            this.EXIT_btn.TabIndex = 4;
            this.EXIT_btn.Text = "EXIT";
            this.EXIT_btn.UseVisualStyleBackColor = false;
            this.EXIT_btn.Click += new System.EventHandler(this.EXIT_btn_Click);
            // 
            // Sold_and_Unsold_Cars
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1142, 449);
            this.Controls.Add(this.EXIT_btn);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Unsoldchk_box);
            this.Controls.Add(this.Soldchk_box);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Sold_and_Unsold_Cars";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Sold_and_Unsold_Cars";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.CheckBox Soldchk_box;
        private System.Windows.Forms.CheckBox Unsoldchk_box;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button EXIT_btn;
    }
}