﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car_showroom_winapp
{
    public partial class EDIT_CAR : Form
    {
        public EDIT_CAR()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
           
        }

        private void dlt_btn_Click(object sender, EventArgs e)
        {
            ADDNEW_CAR ac = new ADDNEW_CAR()
            {
               Chasis = textBox1.Text
            };
            ac.Delete();
            MessageBox.Show("RECORD DELETED");
            EDIT_CAR ec = new EDIT_CAR();
            ec.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {


                ADDNEW_CAR A_C = new ADDNEW_CAR()
                {

                    Make = Make_txt.Text,
                    Model = Convert.ToInt32(Model_txt.Text),
                    Chasis = Chasis_txt.Text,
                    Colour = Colour_txt.Text,
                    Kms = Kms_txt.Text,
                    Address = Address_txt.Text,
                    Description = Description_txt.Text,
                    Cost = Convert.ToDecimal(Cost_txt.Text),
                    Price = Convert.ToDecimal(price__txt.Text),
                    Type = Type_txt.Text,


                };
                A_C.EDIT();
                MessageBox.Show("RECORD EDITED");
                this.Refresh();

            }

            catch (Exception ex)
            {
                throw ex;

                //if (Chasis_txt.Text == "")
                //{
                //    MessageBox.Show("Plesase Enter in a Correct Format");
                //    this.Refresh();
                //}
               

            }
        }

        private void EDIT_CAR_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                ADDNEW_CAR b = new ADDNEW_CAR()
                {
                    Chasis = textBox1.Text.TrimEnd()
                };
                ADDNEW_CAR d = b.Search();
                if (textBox1.Text != "")
                {


                    Make_txt.Text = d.Make;
                    Model_txt.Text = d.Model.ToString();
                    Chasis_txt.Text = d.Chasis;
                    Colour_txt.Text = d.Colour;
                    Kms_txt.Text = d.Kms;
                    Address_txt.Text = d.Address;
                    Description_txt.Text = d.Description;
                    Cost_txt.Text = d.Cost.ToString();
                    Type_txt.Text = d.Type.ToString();
                    price__txt.Text = d.Price.ToString();
                    
                }
            }
            catch (Exception )
            {
                MessageBox.Show("This chasis Number Dosn't Exist");
           
            }
           
        }
    }
}
