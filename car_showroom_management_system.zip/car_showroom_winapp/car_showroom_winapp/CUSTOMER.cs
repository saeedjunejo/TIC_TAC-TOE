﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace car_showroom_winapp
{
    class CUSTOMER
    {
        public string Customer_name { get; set; }
        public string Customer_number { get; set; }
        public string Address { get; set; }


        public void ADD()
        {

            string query = "insert into tbl_Customer values('" + Customer_name + "','" +Customer_number + "','" + Address + "') ";
            SqlCommand SC = new SqlCommand(query, Connection.Get());
            SC.ExecuteNonQuery();
        }

        public void Delete()
        {
            string query = "delete tbl_Customer where Customer_name ='" + Customer_name + "'";
            SqlCommand SC = new SqlCommand(query, Connection.Get());
            SC.ExecuteNonQuery();

        }


    }
}
